1) You can use the New-Service command to install the service
2) Before starting it, make sure that there is a C:\Temp folder